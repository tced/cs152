#define YY_NO_UNPUT 

using namespace std; 

#include <iostream> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include <vector>
#include <queue> 
#include <stack>
#include <string> 
